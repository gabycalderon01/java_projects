package pa8portfolio;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author spenc
 */
public class PA8PortfolioMainCalderonKaup 
{
    public static void main(String[] args) 
    {
        // TODO code application logic here
        PortfolioJFrameDelegateCalderonKaup frame = new 
                                        PortfolioJFrameDelegateCalderonKaup();
    }//End main method 
}
