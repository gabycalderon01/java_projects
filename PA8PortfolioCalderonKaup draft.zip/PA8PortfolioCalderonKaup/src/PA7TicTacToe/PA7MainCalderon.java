/*
 * CPS 202
 * Gabriela Calderon
 * April 7, 2021
 */
package PA7TicTacToe;

/**
 * File name:   PA7MainCalderon.java
 * Description: this is the main class.
 * @author      Gabriela Calderon
 * @revision    April 7, 2021
 */
public class PA7MainCalderon 
{
    /**
     * Main class used to run the program.
     * @param args 
     */
    public static void main(String[] args)
    {
        TicTacToeJFController controller = new TicTacToeJFController();
    }    
} //End of the main class.
