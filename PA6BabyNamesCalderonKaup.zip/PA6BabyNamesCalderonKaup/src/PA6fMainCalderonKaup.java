/*
 * CPS 202
 * Gabriela Calderon & Spencer Kaup
 * 22 March 2021
 */
package pa6BabyNames;


/**
 * File name:   PA6MainCalderonKaup.java
 * Description: this class calls the delegate class and prints out all the
 *              output.
 * @author      Gabriela Calderon & Spencer Kaup
 * @revision    March 22, 2021
 */
public class PA6fMainCalderonKaup 
{
    /**
     * Main class
     * @param args 
     */
    public static void main(String[] args)
    {
        BabyNamesJODelegate delegate = new BabyNamesJODelegate();               
    }
} //End of Main class
