/*
 * CPS 202
 * Spring 2020
 * Will Bohlen
 */
package pa2feb5bohlen;

/**
 * File name:    PA2BohlenJava.java <p>
 * Description:  Programming Project 2, Savitch 6e, Ch. 6, p. 419.
 *               <p>
 *               Main class for PA2.
 * 
 * @author Will Bohlen
 * @version 05-Feb-2020
 */
public class PA2BohlenMain 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        GameController memoryGame = new GameController();
    }
}
