/*
 * CPS 202
 * Will Bohlen
 * 4-May-2020
 */
package pa8portfoliobohlen;

/**
 * File name:     PA8PortfolioMainBohlen.java <p>
 * Description:   Programming Assignment 8 (JMenu Portfolio)
 *                <p>
 *                This program calls the controller class.
 * 
 * 
 * @author Will Bohlen wbohlen@heidelberg.edu
 * @revision 4-May-2020
 */
public class PA8PortfolioMainBohlen {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        PA8PortfolioJFrameDelegateBohlen frame = new PA8PortfolioJFrameDelegateBohlen();
    }//End main method
    
}//End class PA8PortfolioMainBohlen
