/*
 * CPS 202
 * Gabriela Calderon & Spencer Kaup
 * 15 March 2021
 */
package pa5BabyNames;


/**
 * File name:   PA5MainCalderonKaup
 * Description: this class calls the delegate class and prints out all the
 *              output.
 * @author      Gabriela Calderon & Spencer Kaup
 * @revision    March 15, 2021
 */
public class PA5fMainCalderonKaup 
{
    /**
     * Main class
     * @param args 
     */
    public static void main(String[] args)
    {
        BabyNamesJODelegate delegate = new BabyNamesJODelegate();        
    }
} //End of Main class
